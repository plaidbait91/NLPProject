from csv import writer
import pandas as pd
from sklearn.model_selection import train_test_split

data = pd.read_csv('Spam Dataset All.csv')
rows=data.values.tolist()


X_train, X_test = train_test_split(rows,test_size=0.6)

with open('Spam Dataset All.csv', 'a') as f_object:
    writer_object = writer(f_object)
    for x in X_train:
        writer_object.writerow(x)
    f_object.close()

with open('Train Final.csv', 'a') as f_object:
    writer_object = writer(f_object)
    for x in X_test:
        writer_object.writerow(x)
    f_object.close()

print("Done")